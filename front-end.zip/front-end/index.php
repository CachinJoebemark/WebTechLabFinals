<?php
  session_start();
  require_once('dbconfig/config.php');
 ?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Freelancer - Start Bootstrap Theme</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/freelancer.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase" id="mainNav" style="background-color: black !important;">
       <div class="container">
        <a class="navbar-brand js-scroll-trigger text-white" href="#page-top">Home</a>
           
        <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#portfolio">Rents</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
            <?php
              if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                  echo "<a class='nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger' href='#contact'>". $_SESSION['username'] ."</a>";
              } else {
                  echo "<a class='nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger' href='login.php'>Login or Register</a>";
              }
               ?>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <?php
              if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                  echo "<a class='nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger' href='logout.php'>Logout</a>";
              } else {
                  echo "";
              }
               ?>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Header -->
     <div class="home" style="background-image: url(img/renthouse.jpeg);">
        <h1 class="text-uppercase mb-0" id="title">BAHAY BAHAYAN RENTING SERVICES</h1>       
      </div>

    <!-- Portfolio Grid Section -->
    <section class="portfolio body" id="portfolio" style="background-image: url(img/house.jpeg);">
      <div class="container">
        <h2 class="text-center text-uppercase mb-0" style="background-color: white; opacity: .7; color: black; max-width: 100%; padding: 10px 10px 10px 10px;">Available Transients</h2>
        <div class="row">
        <?php
       $query1 = "SELECT house.house_id, house.house_name, house.house_style, house.house_capacity, house.rental_type, house.current_rental_fee, house.current_reservation_fee, house.house_address, house.house_description, images.image_path FROM house JOIN images ON house.house_id = images.house_id WHERE house.house_id NOT IN (SELECT house_id FROM reservation WHERE reservation_status = 'accepted')";
            $result1 = mysqli_query($con, $query1);
        if(mysqli_num_rows($result1) > 0)
            {
              $rowCount = 0;
              while($row = mysqli_fetch_array($result1))
              {
                $rowCount++;
                
                 
          
                 
          ?>
          <div class="col-md-6 col-lg-4">
            <a class="portfolio-item d-block mx-auto" href="#portfolio-modal-<?php echo $rowCount;?>">
              <div class="portfolio-item-caption d-flex position-absolute h-100 w-100">
                <div class="portfolio-item-caption-content my-auto w-100 text-center text-white">
                  <i class="fas fa-search-plus fa-3x"></i>
                </div>
              </div>
              <?php echo '<img class="img-fluid" style=height:500px; width:500px; src="data:image/jpg;base64,' . base64_encode($row['image_path']) . '">';?>
              <br>
              <h4 class="text-center text-secondary"><?php echo $row["house_name"]; ?></h4>
            </a>
          </div>
          <?php
              }
            }
          ?>
        </div>
      </div>
    </section>

    <!-- Profile Section -->
    <section id="contact" style="background-image: url(img/profile.jpeg);" class="body">
      <div class="container text-secondary" >
                <div class="jumbotron">
                  <div class="row">
                    <?php
                        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                              $query = "SELECT * FROM users WHERE username = '".$_SESSION['username']."';";
                            $result = mysqli_query($con, $query);
                          if(mysqli_num_rows($result) > 0) {
                                while($row = mysqli_fetch_array($result))
                                {
                    ?>
                      <div class="col-md-4 col-xs-12 col-sm-6 col-lg-4">
                          <img src="https://www.svgimages.com/svg-image/s5/man-passportsize-silhouette-icon-256x256.png" alt="stack photo" class="img">
                      </div>

                      <div class="col-md-8 col-xs-12 col-sm-6 col-lg-8">
                          <div class="container" style="border-bottom:1px solid black">
                            <h2><?php echo $row["given_name"].' '.$row["last_name"]; ?></h2>
                          </div>
                            <hr>
                          <ul class="container details">
                            <li><p><span class="glyphicon glyphicon-earphone one" style="width:50px;"></span><?php echo $row["contact_no"]?></p></li>
                            <li><p><span class="glyphicon glyphicon-envelope one" style="width:50px;"></span><?php echo $row["email_address"]?></p></li>
                            <li><p><span class="glyphicon glyphicon-map-marker one" style="width:50px;"></span>Hyderabad</p></li>
                          </ul>
                      </div>
                  </div>
                </div>
                <?php
                                }
                          } else {
                            echo "error";
                          }
                        } else {
                            echo "<h3><a href='login.php'>Login/Signup</a></h3>";
                          
                    }
                ?>
    </section>
   
    <div class="copyright py-4 text-center text-white" style="background-color: black">
      <div class="container">
        <small>Copyright &copy; Web Systems and Technology 2018</small>
      </div>
    </div>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-to-top d-lg-none position-fixed ">
      <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>

    <!-- Portfolio Modals -->

    <!-- Portfolio Modal 1 -->
    <?php
        $query = "SELECT house.house_id, house.house_name, house.house_style, house.house_capacity, house.rental_type, house.current_rental_fee, house.current_reservation_fee, house.house_address, house.house_description, images.image_path FROM house JOIN images ON house.house_id = images.house_id WHERE house.house_id NOT IN (SELECT house_id FROM reservation WHERE reservation_status = 'accepted')";
            $result = mysqli_query($con, $query);
        if(mysqli_num_rows($result) > 0)
            {
              $count = 0;
              while($row = mysqli_fetch_array($result))
              {
                $count++;

                 
          ?>
    <div class="portfolio-modal mfp-hide" id="portfolio-modal-<?php echo $count;?>">
      <div class="portfolio-modal-dialog" style="background-image: url(img/modal.jpeg);">
        <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
          <i class="fa fa-3x fa-times"></i>
        </a>
        <div class="container text-center">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <h2 class="text-secondary text-uppercase mb-0"><?php echo $row["house_name"]; ?></h2>
              <?php echo '<img class="img-fluid mb-5" style=height:500px; width:500px; src="data:image/jpg;base64,' . base64_encode($row['image_path']) . '">';?>
              <h4 class="text-secondary text-uppercase" style="text-align: left">House style: <span class="text-primary"><?php echo $row["house_style"]; ?></span></h4>
              <h4 class="text-secondary text-uppercase" style="text-align: left">Capacity: <span class="text-primary"> <?php echo $row["house_capacity"]; ?></span></h4>
              <h4 class="text-secondary text-uppercase" style="text-align: left">Type:  <span class="text-primary"> <?php echo $row["rental_type"]; ?></span></h4>
              <h4 class="text-secondary text-uppercase" style="text-align: left">Rental Fee:  <span class="text-primary"><?php echo $row["current_rental_fee"]; ?></span></h4>
              <h4 class="text-secondary text-uppercase" style="text-align: left">Rental Fee:  <span class="text-primary"><?php echo $row["current_reservation_fee"]; ?></span></h4>
              <h4 class="text-secondary text-uppercase" style="text-align: left">Address:  <span class="text-primary"><?php echo $row["house_address"]; ?></span></h4>
              <p class="mb-5 text-secondary" style="font-size: x-large;"><?php echo $row["house_description"]; ?></p>
              <form action="rentHouse.php" method="post" autocomplete="off" class="mb-5 text-secondary" style="font-size: x-large;">
     from:<input type="date" name="from">
     to:<input type="date" name="to">
    <button class="btn btn-secondary btn-lg rounded-pill" type="submit" name="rent">Rent</button>
  </form>
<?php  
if(isset($_POST['rent']))
      {
        @$from=$_POST['from'];
        @$to=$_POST['to'];
        echo "$from";
        echo "$to";
        if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                  $query = "INSERT INTO reservation (user_id, house_id, reservation_startdate, reservation_enddate, reservation_status)
VALUES ((select user_id from users where user_id = '".$_SESSION['user_id']."'), (select house_id from house where house_id = '119'), ".$from.", ".$to.", 'pending')";
//VALUES ((select user_id from users where user_id = '1'), (select house_id from house where house_id = '119'), 2018-11-5, 20119-11-6, 'pending')
echo "$query";
                if(mysqli_query($con, $query)) {
                    echo '<script type="text/javascript">alert("rental successful")</script>';
                    header( "Location: profile.php");
              } else {
                echo '<script type="text/javascript">alert("not inserted")</script>';
              }
            } else {
                echo "<a href='login.php'>Login/Signup</a>";
              
        }
      } else {
      }
?>
<br>
<br>
              <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                <i class="fa fa-close"></i>
                Close Window</a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
              }
            }
          ?>

  

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/freelancer.min.js"></script>

  </body>

</html>
