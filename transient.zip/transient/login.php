<?php
  session_start();
  require_once('dbconfig/config.php');
 ?>
<html>
  <head>
    <meta charset="utf-8">
    <title>Login</title>
     <link href="css/regis.css" rel="stylesheet">
     <link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/css/materialize.min.css" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css?family=Pacifico" rel="stylesheet">
     <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/js/materialize.min.js"></script>
     <script type="text/javascript" src="js/regis.js"></script>

    <!-- Custom styles for this template -->
    <link href="css/heroic-features.css" rel="stylesheet">
  </head>
  <body class="body" style="background-image: url(img/regis.jpeg);">
   <<nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase" id="mainNav" style="background-color: black !important;">
      <div class="container">
        <a class="navbar-brand" href="index.php">Go back to website</a>

      </div>
    </nav>
    <div class="row">
      <div class="input-cart col s12 m10 push-m1 z-depth-2 grey lighten-5">
        <div class="col s12 m5 login">
          <h4 class="center">Log in</h4>
          <br>
          <form action="login.php" method="post" autocomplete="off">
            <div class="row">
              <div class="input-field">
                <input type="text" id="user" name="username" class="validate" required="required" placeholder="Username">
                <label for="user">
                  <i class="material-icons">person</i>
                </label>
              </div>  
            </div>
            <div class="row">
              <div class="input-field">
                <input type="password" id="pass" name="password" class="validate" required="required" placeholder="Password">
                <label for="pass">
                <i class="material-icons">lock</i>
                </label>
              </div>  
            </div>
            <div class="row">
              <div class="col s6">
                <button type="submit" name="login" class="btn waves-effect waves-light blue right">Log in</button>
              </div>
            </div>
          </form>
        </div>
        <?php
      if(isset($_POST['login']))
      {
        @$username=$_POST['username'];
        @$password=$_POST['password'];
        @$client_id=$_POST['user_id'];
        $query = "select * from users where username='$username' and password='$password' ";
        //echo $query;
        $query_run = mysqli_query($con,$query);
        //echo mysql_num_rows($query_run);
        if($query_run)
        {
          if(mysqli_num_rows($query_run)>0)
          {
          $row = mysqli_fetch_array($query_run,MYSQLI_ASSOC);
          
          $_SESSION['loggedin'] = true;
          $_SESSION['username'] = $username;
          $_SESSION['password'] = $password;
          $_SESSION['user_id'] = $row["user_id"];;
          
          header( "Location: index.php");
          }
          else
          {
            echo '<script type="text/javascript">alert("No such User exists. Invalid Credentials")</script>';
          }
        }
        else
        {
          echo '<script type="text/javascript">alert("Database Error")</script>';
        }
      }
      else
      {
      }
    ?>
    <?php
      if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                  
      } else {
                  echo "<a class='nav-link' href='index.php'></a>";
    ?>
        <!-- Signup form -->
        <div class="col s12 m7 signup">
        <div class="signupForm">
          <h4 class="center">Sign up</h4>
          <br>
          <form action="login.php" method="post" autocomplete="off">
            <div class="row">
              <div class="input-field col s12 m6">
                <input type="text" id="name-picked" name="username" class="validate" required="required" placeholder="Enter a username">
                <label for="name-picked">
                       <i class="material-icons">person_add</i>       
                </label>
              </div>
              <div class="input-field col s12 m6">
                <input type="password" id="pass-picked" name="password" class="validate" required="required" placeholder="Password">
                <label for="pass-picked">
                  <i class="material-icons">lock</i>                    </label>
              </div>  
                <div class="input-field col s12 m6">
                <input type="password" id="pass-confirm" name="confirmpass" class="validate" required="required" placeholder="Confirm Password" data-match="#pass-picked" data-match-error="Password not matched.">
                <label for="pass-picked">
                  <i class="material-icons">lock</i>                    </label>
              </div>  
            </div>
            <div class="row">
              <div class="input-field email col s12 m6">
                  <input type="text" id="email" name="email" class="validate" required="required" placeholder="Enter your email">
                  <label for="email">
                    <i class="material-icons">mail</i> 
                  </label>
                </div>
               
                  <div class="custom-control custom-radio col s12 m6">
                        <input type="radio" class="custom-control-input" id="defaultChecked" name="gender" value="male" checked>
                        <label class="custom-control-label" for="defaultChecked">Male</label>
                  </div>
                   <div class="custom-control custom-radio col s12 m6">
                           <input type="radio" class="custom-control-input" id="defaultUnchecked" name="gender" value="female">
                        <label class="custom-control-label" for="defaultUnchecked">Female</label>
                   </div>
                  
            </div>  
            <div class="row">
              <div class="input-field col s12 m6">
                <input type="text" id="name-picked" name="firstname" class="validate" required="required" placeholder="Firstname">
                <label for="name-picked">
                       <i class="material-icons">person_add</i>       
                </label>
              </div>  
              <div class="input-field col s12 m6">
                <input type="text" id="name-picked" name="lastname" class="validate" required="required" placeholder="Lastname">
                <label for="name-picked">
                       <i class="material-icons">person_add</i>       
                </label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12 m6">
                <input type="password" id="pass-picked" name="phone_number" class="validate" required="required" placeholder="Phone Number">
                <label for="pass-picked">
                  <i class="material-icons">person_add</i>                    </label>
              </div>
                  <div class="custom-control custom-radio col s12 m6">
                        <input type="radio" class="custom-control-input" id="defaultCheckedTy" name="user" value="user" checked>
                        <label class="custom-control-label" for="defaultCheckedTy">User</label>
                  </div>
                  
                   <div class="custom-control custom-radio col s12 m6">
                        <input type="radio" class="custom-control-input" id="defaultUncheckedTy" name="user" value="provider">
                        <label class="custom-control-label" for="defaultUncheckedTy">Service Provider</label>
                   </div> 
            </div>
            <div class="row">
            <button type="submit" name="signup" class="btn blue right waves-effect waves-light">Sign Up</button>
          </div>
          </form>
          
          </div>
          
          <?php
      if(isset($_POST['signup']))
      {
        $username=$_POST['username'];
        $password=$_POST['password'];
        $email=$_POST['email'];
        $firstname=$_POST['firstname'];
        $lastname=$_POST['lastname'];
        $phone_number=$_POST['phone_number'];
        $gender=$_POST['gender'];
        $user=$_POST['user'];
        
          $query = "select * from users where username ='$username'";
          //echo $query;
        $query_run = mysqli_query($con, $query);
        //echo mysql_num_rows($query_run);
        if($query_run)
          {
            if(mysqli_num_rows($query_run)>0)
            {
              echo '<script type="text/javascript">alert("This Username Already exists.. Please try another username!")</script>';
            }
            else
            {
              $sql = "INSERT INTO users (username, password, email_address, given_name, last_name, contact_no, user_type, account_status, gender) VALUES ('$username', '$password', '$email', '$firstname', '$lastname', '$phone_number', '$user', 'pending', '$gender')";
              /*$query_run = mysqli_query($con, $sql);
              if($query_run) {*/
            if($con->query($sql)) {
                echo '<script type="text/javascript">alert("User Registered.. Welcome")</script>';
                echo '<script type="text/javascript">window.location.href="login.php")</script>';
              /*$stmt = $con->prepare("INSERT INTO users (username, password, email_address, given_name, last_name, contact_no, user_type, account_status, gender) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
              $stmt->bind_param('sssssssss', $username, $password, $email, $firstname, $lastname, $phone_number, $user_type, $account_status, $gender);
              $username = $username;
              $password = $password;
              $email = $email;
              $firstname = $firstname;
              $lastname = $lastname;
              $phone_number = $phone_number;
              $user_type = $user;
              $account_status = 'pending';
              $gender = $gender;
              $stmt->execute();
              if($query_run)
              {
                echo '<script type="text/javascript">alert("User Registered.. Welcome")</script>';
                echo '<script type="text/javascript">window.location.href="login.php")</script>';*/
              }
              else 
            {
                echo "Error updating record: " . $con->error;
            }
            }
          }
          else
          {
            echo '<script type="text/javascript">alert("DB error")</script>';
          }
        
        
      }
      else
      {
      }
    ?>
          <div class="signup-toggle center" >
            <h4 class="center">Have No Account ? <a href="#!">Sign Up</a></h4>
          </div>
          <?php
            }
          ?>
        </div>
        <div class="col s12">
          <br>
          <div class="legal center">
          </div>
        </div>
      </div>
    </div>
  </body>
</html>