if(isset($_POST['signup']))
      {
        @$username=$_POST['username'];
        @$password=$_POST['password'];
        @$cpassword=$_POST['confirmpass'];
        @$email=$_POST['email'];
        @$firstname=$_POST['firstname'];
        @$lastname=$_POST['lastname'];
        @$phone_number=$_POST['phone_number'];
        @$gender=$_POST['gender'];

        if($password==$cpassword)
        {
          $query = "select * from users where username ='$username'";
          //echo $query;
        $query_run = mysqli_query($con, $query);
        //echo mysql_num_rows($query_run);
        if($query_run)
          {
            if(mysqli_num_rows($query_run)>0)
            {
              echo '<script type="text/javascript">alert("This Username Already exists.. Please try another username!")</script>';
            }
            else
            {
              $stmt = $con->prepare("INSERT INTO users (username, password, email_address, given_name, last_name, contact_no) VALUES (?, ?, ?, ?, ?, ?)");
              $stmt->bind_param('ssssss', $username, $password, $email, $firstname, $lastname, $phone_number);
              $username = $username;
              $password = $password;
              $email = $email;
              $firstname = $firstname;
              $lastname = $lastname;
              $phone_number = $phone_number;
              $user_type = 'user';
              $stmt->execute();
              if($query_run)
              {
                echo '<script type="text/javascript">alert("User Registered.. Welcome")</script>';
                $_SESSION['username'] = $username;
                $_SESSION['password'] = $password;
                $_SESSION['email'] = $email;
                $_SESSION['firstname'] = $firstname;
                $_SESSION['lastname'] = $lastname;
                $_SESSION['phone_number'] = $phone_number;
                header( "Location: index.php");
              }
              else
              {
                echo '<p class="bg-danger msg-block">Registration Unsuccessful due to server error. Please try later</p>';
              }
            }
          }
          else
          {
            echo '<script type="text/javascript">alert("DB error")</script>';
          }
        }
        else
        {
          echo '<script type="text/javascript">alert("Password and Confirm Password do not match")</script>';
        }
        
      }
      else
      {
      }