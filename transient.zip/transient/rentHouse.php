<?php
  session_start();
  require_once('dbconfig/config.php');
 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="rentHouse.php" method="post" autocomplete="off">
		 from:<input type="date" name="from">
		 to:<input type="date" name="to">
		<button type="submit" name="rent">Rent</button>
	</form>
<?php  
if(isset($_POST['rent']))
      {
      	$from=$_POST['from'];
        $to=$_POST['to'];
        $fromC= strtotime ( $from );
        $toC= strtotime ( $to );
        echo "$from";
        echo "$to";
      	if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                	$query = "INSERT INTO reservation (user_id, house_id, reservation_startdate, reservation_enddate, reservation_status)
VALUES ((select user_id from users where user_id = '".$_SESSION['user_id']."'), (select house_id from house where house_id = '119'), '".$from."', '".$to."', 'pending')";
//VALUES ((select user_id from users where user_id = '1'), (select house_id from house where house_id = '119'), 2018-11-5, 20119-11-6, 'pending')
echo "$query";
            		if(mysqli_query($con, $query)) {
              			echo '<script type="text/javascript">alert("rental successful")</script>';
              			header( "Location: profile.php");
         			} else {
        				echo '<script type="text/javascript">alert("not inserted")</script>';
    	   			}
            } else {
              	echo "<a href='login.php'>Login/Signup</a>";
            	
    		}
    	} else {
    	}
?>
</body>
</html>
