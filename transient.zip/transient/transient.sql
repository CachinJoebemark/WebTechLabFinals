-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2018 at 11:37 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `transient`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `activity_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `activity_date` datetime NOT NULL,
  `activity_description` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`activity_id`, `user_id`, `activity_date`, `activity_description`) VALUES
(380, 3, '2018-05-10 11:00:00', 'Seminar at Teacher\'s Camp.'),
(381, 10, '2018-05-20 15:00:00', 'Family Reunion at Baguio City'),
(382, 4, '2018-05-11 09:30:00', 'Unwind from stressful semester'),
(383, 9, '2018-05-30 16:30:00', 'Reunion with friends'),
(384, 7, '2018-06-01 09:30:00', 'Workshop and seminar at Camp John Hay, Baguio City'),
(385, 16, '2018-06-11 11:30:00', 'Family gathering'),
(386, 11, '2018-05-12 09:30:00', 'Hanging out with friends'),
(387, 12, '2018-04-12 12:30:00', 'Vacation'),
(389, 5, '2018-05-14 14:08:00', 'Vacation'),
(390, 10, '2018-05-22 09:45:00', 'Summer vacation');

-- --------------------------------------------------------

--
-- Table structure for table `house`
--

CREATE TABLE `house` (
  `house_id` int(11) NOT NULL,
  `house_name` varchar(45) NOT NULL,
  `house_style` varchar(45) DEFAULT NULL,
  `house_capacity` int(3) NOT NULL,
  `house_description` varchar(200) DEFAULT NULL,
  `house_address` varchar(200) NOT NULL,
  `rental_type` enum('per house','per head') NOT NULL,
  `current_rental_fee` decimal(15,0) NOT NULL,
  `current_reservation_fee` decimal(15,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `house`
--

INSERT INTO `house` (`house_id`, `house_name`, `house_style`, `house_capacity`, `house_description`, `house_address`, `rental_type`, `current_rental_fee`, `current_reservation_fee`) VALUES
(111, 'Lyn\'s Baguio Transient Homes', 'Guest House', 2, 'Lyn\'s Baguio Transient Homes is a nice place with good ambiance that is good for big family.', '79-B, City Camp Alley, Baguio, 2600 Benguet', 'per head', '2500', '500'),
(112, 'Baguio Transient House', 'Townhouse', 15, 'Baguio Transient House serves a wide space with parking lot.', '300 Elizabeth Court, Suello Village, Baguio, 2600 Benguet', 'per house', '8000', '2500'),
(113, 'Baguio Transient', 'Lodge', 10, 'Baguio Transient is known for the best home in town.', '214 Mission Rd, Crystal Cave, Baguio', 'per house', '7000', '2500'),
(114, 'Babsplace Baguio Transient Room', 'Bed space', 1, 'Band looking for comfortable day and night stay.\r\n', '508 Hillside Rd, Baguio', 'per head', '1500', '500'),
(115, 'Kaleen\'s Baguio Transient House', '3-Star Hotel', 5, 'This place is less expensive compared to hotel accommodations.', '1354 Asin Rd, Baguio', 'per house', '8960', '3500'),
(116, 'Baguio Affordable Transient House', 'Guest House', 6, 'Good for 5-6 person, free Wi-Fi and semi-furnished house, clean and affordable.', 'Valenzuela St, Baguio, Benguet', 'per head', '600', '250'),
(117, 'Nice n\' Cozy Transient House', 'Bungalow', 10, 'Semi furnished house and elegant décor.', '104 Upper East, Purok-1 Kalinga Pelota, Camp 7, Baguio', 'per house', '6000', '2000'),
(118, 'Pam\'s Transient House', 'Guest House', 4, '2-Storey House with free wi-fi.', '23 R. Villalon St, Baguio, 2600 Benguet', 'per house', '3000', '1500'),
(119, 'Monzon\'s Transient Homes', 'Duplex House', 6, '15 mins walking to town. Free Wi-Fi and CCTV access.', '65 Everlasting St, Baguio, 2600 Benguet', 'per house', '3500', '1500'),
(120, 'God\'s Love Baguio Transient House', '3 Star Hotel', 2, NULL, 'Sandico St, Salud Mitra, Baguio, 2600 Benguet', 'per head', '500', '250'),
(121, 'Zeb\'s Transient House', 'Triplex House', 8, 'Fully furnished house with hot and cold water. Wi-Fi free and parking lot.', 'Green Ln, Baguio, Benguet', 'per house', '4500', '1300'),
(122, 'Joann Transient House', 'Bachelors Pad', 2, NULL, '18 Laubach Rd, Baguio, 2600 Benguet', 'per head', '2500', '850'),
(123, 'VMSunga Transient House', 'Country and Rustic', 10, 'Semi furnished house and free Wi-Fi with parking lot.', '282 Elizabeth Court Suello Village, Baguio City, Elisabeth Ct, Baguio, Benguet', 'per house', '5500', '2500'),
(124, 'Transient House Baguio', 'Lodge', 10, 'Fully furnished house, CCTV and Wi-Fi free.', 'Loakan Liwanag Barangay Hall, 233 2 Upper, Loakan Rd, Baguio, Benguet', 'per house', '6500', '3000'),
(125, 'Woodsgate Transient House', 'Chic and Stylish', 15, 'Wide space and can accommodate 15 person. 4 rooms with 3 beds.', '139 Purok 1 Upper East Camp 7 Binay-an Compound, Baguio, 2600 Binay-an Compound, Baguio, 2600 Benguet', 'per head', '650', '200'),
(126, 'Colorful Transient House', 'Bungalow', 5, '27/1 vehicle access. 24/7 cctv secured and parking lot.', '224 Purok 1, Upper East Woodsgate Square, Camp 7, Baguio, 2600', 'per house', '3500', '1800'),
(127, 'Maine Line Transient House', 'Townhouse', 8, NULL, 'Baguio, Benguet', 'per house', '4500', '2800'),
(128, 'Mj Transient House', 'Bungalow', 4, 'Free Wi-Fi access', 'San Carlos Heights, Baguio, Benguet', 'per house', '3500', '1000'),
(129, 'Peter\'s Baguio Transient House', 'Bachelors Pad', 7, 'Fully furnished transient house with free Wi-Fi access.', '2602, 163 Military Cutoff Rd, Baguio, Benguet', 'per head', '500', '150'),
(130, 'Jabbitos Transient House', 'Bachelors Pad', 2, NULL, 'C. Arellano St, Baguio, Benguet', 'per head', '500', '250'),
(131, 'Breezy Hill Transient House', 'Duplex', 8, 'Semi furnished transient house, hot and cold water, free Wi-Fi and free parking lot.', '18 V. Martinez St, Brgy. Engineers Hill, Baguio, 2600 Benguet', 'per house', '4500', '2500'),
(132, 'Tonyen\'s Transient House', 'Bungalow', 6, 'Quiet place, good for relaxation and unwind.', 'Bakakeng Road, 13c Western Link Circumferential Rd, Baguio, 2600\r\n', 'per house', '3500', '1000'),
(133, 'Sagun\'s Transient House', 'Apartment/Boarding', 2, 'Good for 2 person. Hot and cold water with Free Wi-Fi.', '65 M. Roxas Street, Imelda Village, Baguio, 2600 Benguet', 'per house', '3800', '1500'),
(134, 'Outlook Transient House', 'Guest House', 5, '24/7 CCTV access with free Wi-Fi and hot and cold water.', '#11, Maryhurst Rd. Brgy. Outlook Drive Subd., Baguio, 2600 Benguet', 'per house', '4500', '2000'),
(135, 'Faes Transient House', 'Chic and Stylish', 10, '3 Storey house with parking lot.', '2 himalaya St. Shangrila village, Baguio, 2600 Benguet', 'per house', '5500', '2800'),
(136, 'Gutierrez Transient House', 'American Architecture', 12, 'Free Wi-Fi and CCTV secured. Near Grotto Lourdes.', '#61, Dominican Road, Brgy. Dominican Mirador, Baguio, 2600 Benguet', 'per house', '6500', '3000'),
(137, 'Gutierrez Transient House', 'Triplex', 5, 'Semi furnished house with parking lot. Free Wi-Fi access.', '#61, Dominican Road, Brgy. Dominican Mirador, Baguio, 2600 Benguet', 'per house', '3800', '1200'),
(138, 'Royale Seven Transient House', 'Guest House', 12, 'Good for 12 person, wide space, free wi-fi, cctv access and no water problem.', 'Ace Villa Royale 7, Green Valley Village,, Santo Tomas Road,, Dontogan, Baguio, 2600 Benguet', 'per house', '5200', '2300'),
(139, 'Zya Transient House', 'Country and Rustic', 8, NULL, 'Alphaville St, Baguio, Benguet', 'per head', '500', '250'),
(140, 'LuPris Baguio Transient House', 'Bungalow', 4, 'CCTV secured. No water problem and Free Wi-Fi.', 'Lower Brookside, Baguio, Benguet', 'per house', '3500', '1200'),
(141, 'Kiyomi\'s Transient House', 'Triplex', 8, NULL, '12, Badihoy, Baguio, Benguet', 'per house', '5500', '2000');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `image_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `house_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rental_id` int(11) NOT NULL,
  `payment_date` datetime NOT NULL,
  `payment_amount` decimal(15,0) NOT NULL,
  `payment_remarks` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `user_id`, `rental_id`, `payment_date`, `payment_amount`, `payment_remarks`) VALUES
(200, 6, 911, '2018-05-15 00:00:00', '5500', NULL),
(201, 11, 915, '2018-05-15 11:00:00', '1500', 'Pending transaction'),
(202, 5, 919, '2018-05-12 06:00:00', '1050', 'To be followed'),
(203, 12, 910, '2018-05-15 16:30:00', '3500', 'Booked May/15/18'),
(204, 6, 916, '2018-05-27 09:30:00', '3800', 'Pending transaction'),
(205, 14, 912, '2018-06-05 11:00:00', '4800', 'To be followed'),
(206, 8, 919, '2018-07-12 06:00:00', '2800', 'Cancelled transaction'),
(207, 3, 911, '2018-05-11 12:00:00', '5500', 'Reserved transaction'),
(208, 5, 915, '2018-05-11 06:30:00', '5850', 'Ongoing transaction'),
(209, 1, 914, '2018-05-11 08:30:00', '3000', 'Ongoing transaction'),
(210, 2, 913, '2018-05-13 08:30:00', '3500', 'To be followed'),
(211, 10, 912, '2018-06-18 00:00:00', '7000', 'Completed'),
(212, 10, 912, '2018-06-18 00:00:00', '7000', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `rental`
--

CREATE TABLE `rental` (
  `rental_id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `rental_startdate` date NOT NULL,
  `rental_enddate` date DEFAULT NULL,
  `rental_fee` decimal(15,0) NOT NULL,
  `fee_to_provider` decimal(15,0) NOT NULL,
  `rental_status` enum('pending','ongoing','completed') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rental`
--

INSERT INTO `rental` (`rental_id`, `reservation_id`, `rental_startdate`, `rental_enddate`, `rental_fee`, `fee_to_provider`, `rental_status`) VALUES
(910, 810, '2018-05-13', '2018-05-15', '3500', '120', 'pending'),
(911, 811, '2018-05-11', '2018-05-15', '5500', '150', 'completed'),
(912, 812, '2018-06-05', '2018-06-06', '4800', '1200', 'completed'),
(913, 813, '2018-05-29', '2018-05-30', '6500', '2000', 'ongoing'),
(914, 814, '2018-05-11', '2018-05-12', '3000', '1250', 'completed'),
(915, 815, '2018-05-11', '2018-05-12', '5850', '1500', 'ongoing'),
(916, 816, '2018-05-27', '2018-05-29', '3800', '1200', 'completed'),
(917, 817, '2018-05-11', '2018-05-12', '5500', '2800', 'ongoing'),
(918, 818, '2018-06-10', '2018-05-11', '3500', '1200', 'completed'),
(919, 819, '2018-06-12', '2018-06-12', '2800', '1050', 'pending'),
(920, 814, '2018-05-11', '2018-05-12', '6000', '2000', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `rented_houses`
--

CREATE TABLE `rented_houses` (
  `rented_house_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `house_id` int(11) NOT NULL,
  `date_rented_from` datetime NOT NULL,
  `date_rented_to` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rented_houses`
--

INSERT INTO `rented_houses` (`rented_house_id`, `user_id`, `house_id`, `date_rented_from`, `date_rented_to`) VALUES
(1, 5, 114, '2018-11-08 00:00:00', '2018-11-23 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `reservation_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `house_id` int(11) NOT NULL,
  `reservation_startdate` date NOT NULL,
  `reservation_enddate` date DEFAULT NULL,
  `reservation_fee` decimal(15,0) NOT NULL,
  `reservation_status` enum('pending','cancelled','accepted','rejected') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`reservation_id`, `user_id`, `house_id`, `reservation_startdate`, `reservation_enddate`, `reservation_fee`, `reservation_status`) VALUES
(810, 3, 119, '2018-05-13', '2018-05-15', '1500', 'pending'),
(811, 2, 111, '2018-05-11', '2018-05-15', '500', 'pending'),
(812, 10, 113, '2018-06-05', '2018-06-06', '2500', 'accepted'),
(813, 11, 139, '2018-05-29', '2018-05-30', '250', 'cancelled'),
(814, 13, 117, '2018-05-11', '2018-05-12', '2000', 'pending'),
(815, 14, 118, '2018-05-11', '2018-05-12', '1500', 'rejected'),
(816, 2, 124, '2018-05-27', '2018-05-29', '3000', 'accepted'),
(817, 1, 135, '2018-05-11', '2018-05-12', '2800', 'accepted'),
(818, 10, 125, '2018-06-10', '2018-05-11', '200', 'accepted'),
(819, 3, 139, '2018-06-12', '2018-06-12', '250', 'rejected');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `given_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `gender` enum('female','male') DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `contact_no` varchar(15) DEFAULT NULL,
  `email_address` varchar(45) DEFAULT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `display_picture` varchar(200) DEFAULT NULL,
  `user_type` enum('user','provider','admin') NOT NULL,
  `account_status` enum('pending','accepted','declined','deactivated') NOT NULL,
  `account_balance` decimal(15,0) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `given_name`, `last_name`, `gender`, `birthdate`, `contact_no`, `email_address`, `username`, `password`, `display_picture`, `user_type`, `account_status`, `account_balance`) VALUES
(1, 'Kyrie', 'Cerezo', 'male', '1998-07-14', '0905667894', 'kyrie@gmail.com', 'user1', 'user1', NULL, 'user', 'accepted', '0'),
(2, 'Darryl', 'Dadag', 'male', '1998-12-17', '09752584867', 'Darryl@gmail.com', 'user2', 'user2', NULL, 'user', 'accepted', '0'),
(3, 'Neil', 'Lopez', 'male', '1998-07-01', '09097079999', 'Lopez@gmail.com', 'user3', 'user3', NULL, 'user', 'pending', '0'),
(4, 'Von', 'Manaois', 'male', '1998-06-03', '09096734351', 'VonMan@gmail.com', 'user4', 'user4', NULL, 'admin', 'deactivated', '0'),
(5, 'Cachin', 'Joebemark', 'male', '1998-03-03', '09165634187', 'JBCachin@gmail.com', 'user5', 'user5', NULL, 'provider', 'accepted', '0'),
(6, 'Steven ', 'Mangati', 'male', '1998-08-28', '09557845186', 'ulimangati@gmail.com', 'user6', 'user6', NULL, 'provider', 'accepted', '0'),
(7, 'Palpallatoc', 'Windee', 'male', '1999-05-18', '09752685222', 'wingggg@gmail.com', 'user7', 'user7', NULL, 'admin', 'accepted', '0'),
(8, 'Miah', 'Pimentel', 'male', '1998-09-09', '09156835111', 'fafa@gmail.com', 'user8', 'user8', NULL, 'provider', 'deactivated', '0'),
(9, 'Karlo', 'Dalisay', 'male', '1998-10-21', '09091278440', 'Dalisay@gmail.com', 'user9', 'user9', NULL, 'provider', 'declined', '0'),
(10, 'Siyak', 'Nidaddym', 'male', '1996-01-11', '09123564786', 'daddym@gmail.com', 'user10', 'user10', NULL, 'user', 'pending', '0'),
(11, 'Zac', 'Efron', 'male', '1998-07-11', '09169473522', 'zac@gmail.com', 'user11', 'user11', NULL, 'user', 'accepted', '0'),
(12, 'Princess', 'Quenn', 'female', '1998-01-17', '0916947000', 'quennn@gmail.com', 'user12', 'user12', NULL, 'admin', 'pending', '0'),
(13, 'Taylor', 'Swift', 'female', '1997-08-14', '09474126426', 'Taylor@gmail.com', 'user13', 'user13', NULL, 'user', 'deactivated', '0'),
(14, 'Bella', 'Killa', 'female', '1996-09-12', '09474256589', 'bella@gmail.com', 'user14', 'user14', NULL, 'user', 'accepted', '0'),
(15, 'Christian', 'Khalifa', 'male', '1998-03-14', '09265990873', 'christian@gmail.com', 'user15', 'user15', NULL, 'provider', 'accepted', '0'),
(16, 'Snoop', 'Dog', 'male', '1998-02-05', '09985623420', '420@gmail.com', 'user16', 'user16', NULL, 'admin', 'declined', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `user_idx` (`user_id`);

--
-- Indexes for table `house`
--
ALTER TABLE `house`
  ADD PRIMARY KEY (`house_id`),
  ADD UNIQUE KEY `house_id_UNIQUE` (`house_id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`image_id`),
  ADD KEY `house_idx` (`house_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `rental_idx` (`rental_id`);

--
-- Indexes for table `rental`
--
ALTER TABLE `rental`
  ADD PRIMARY KEY (`rental_id`),
  ADD KEY `reservaation_id_idx` (`reservation_id`);

--
-- Indexes for table `rented_houses`
--
ALTER TABLE `rented_houses`
  ADD PRIMARY KEY (`rented_house_id`),
  ADD KEY `userID` (`user_id`),
  ADD KEY `houseID` (`house_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`reservation_id`),
  ADD KEY `user_id_idx` (`user_id`),
  ADD KEY `house_id_idx` (`house_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username_UNIQUE` (`username`),
  ADD UNIQUE KEY `password` (`password`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=391;

--
-- AUTO_INCREMENT for table `house`
--
ALTER TABLE `house`
  MODIFY `house_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=213;

--
-- AUTO_INCREMENT for table `rental`
--
ALTER TABLE `rental`
  MODIFY `rental_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=921;

--
-- AUTO_INCREMENT for table `rented_houses`
--
ALTER TABLE `rented_houses`
  MODIFY `rented_house_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `reservation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=820;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD CONSTRAINT `user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `house` FOREIGN KEY (`house_id`) REFERENCES `house` (`house_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `rental` FOREIGN KEY (`rental_id`) REFERENCES `rental` (`rental_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rental`
--
ALTER TABLE `rental`
  ADD CONSTRAINT `reservation_id` FOREIGN KEY (`reservation_id`) REFERENCES `reservation` (`reservation_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rented_houses`
--
ALTER TABLE `rented_houses`
  ADD CONSTRAINT `houseID` FOREIGN KEY (`house_id`) REFERENCES `house` (`house_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `userID` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `reservation`
--
ALTER TABLE `reservation`
  ADD CONSTRAINT `house_id` FOREIGN KEY (`house_id`) REFERENCES `house` (`house_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
