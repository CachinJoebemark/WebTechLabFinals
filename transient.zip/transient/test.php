<?php
include('dbconfig/config.php');
$query = "SELECT * from images";
            $result = mysqli_query($con, $query);
        if(mysqli_num_rows($result) > 0)
            {
              $count = 0;
              while($row = mysqli_fetch_array($result))
              {
                $count++;

					echo '<img src="data:image/jpg;base64,' . base64_encode($row['image_path']) . '">';
                 }
            }
?>