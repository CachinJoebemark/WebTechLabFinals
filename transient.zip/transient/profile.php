<?php
  session_start();
  require_once('dbconfig/config.php');
 ?>
<!DOCTYPE html>
<html lang="en">

  <head></head>
  <body>
  	<?php
            if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
                	$query = "SELECT * FROM users WHERE username = '".$_SESSION['username']."';";
            		$result = mysqli_query($con, $query);
        			if(mysqli_num_rows($result) > 0) {
              			while($row = mysqli_fetch_array($result))
              			{
              				?>
              				<h3><?php echo $_SESSION['user_id']?></h3>
                			<h3><?php echo $row["given_name"].' '.$row["last_name"]; ?></h3>
                			<h3><?php echo $row["contact_no"]?></h3>
                			<h3><?php echo $row["email_address"]?></h3>
                			<h3><?php echo $row["account_balance"]?></h3>
                			<?php
              			}
         			} else {
        				echo "error";
    	   			}
            } else {
              	echo "<a href='login.php'>Login/Signup</a>";
            	
    		}
               ?>

  </body>