/**
 * Author: Steven Mangati
 */

console.log("It's working!");

/* Import modules */
const express = require('express');
const session = require('express-session');
const http = require('http');
const mysql = require('mysql');
const app = express();
const bodyParser = require('body-parser');

/* Parses data from form */
app.use(bodyParser.urlencoded({extended: true}));

/* For sessions */
app.use(session({ secret: 'secretdikosasabihin', resave: false, saveUninitialized: false }));

/* For dates */
var dateFormat = require('dateformat');
var now = new Date();

/* View engine */
app.set('view engine', 'ejs');

/* Import JS and CSS, */
app.use('/js', express.static(__dirname + '/node_modules/bootstrap/dist/js'));
app.use('/js', express.static(__dirname + '/node_modules/tether/dist/js'));
app.use('/js', express.static(__dirname + '/node_modules/jquery/dist'));
app.use('/css', express.static(__dirname + '/node_modules/bootstrap/dist/css'));
app.use('/css', express.static(__dirname + '/node_modules/css'));

/* Database connection */
const con = mysql.createConnection({
	host: "192.168.254.105",
	user: "root",
	password: "",
	database: "transient",
	multipleStatements: true
});

/* Declare title and base url */
const siteTitle = "Service Provider";
const baseURL = "http://localhost:4000/"

/*app.post('/house/login', (req, res) => {
	con.query("SELECT * FROM users WHERE username = '" +req.body.username + "' AND user_type = 'provider' AND account_status = 'accepted';" , function (err,result) {
		if (req.body.username&&(req.body.password==result[0].password)) {
			req.session.user_id = result[0].user_id;		
    		res.redirect('/');
		} else {
			res.redirect('/house/login');
		}
	});
});*/

app.post('/house/login', (req, res) => {
	con.query("SELECT * FROM users WHERE username = '"+req.body.username+"' AND user_type = 'provider'", function (err, result) {
		if ((req.body.username==result[0].username)&&(req.body.password==result[0].password)) {
				console.log(result[0].user_type);
				if (result[0].account_status==='accepted') {
					req.session.user_id = result[0].user_id;		
	    			res.redirect('/');
				} else {
					res.redirect('/house/loginpending');
				}
		} else {
			res.redirect('/house/loginerror');
		}		
	});
});

app.get('/house/loginpending', function (req, res) {
	res.render('pages/loginpending.ejs', {
		siteTitle	: siteTitle,
		pageTitle	: "Login"
	});
});

app.get('/house/loginerror', function (req, res) {
	res.render('pages/loginerror.ejs', {
		siteTitle	: siteTitle,
		pageTitle	: "Login"
	});
});

app.get('/house/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/house/login');
});

/* Page loads, load data */
app.get('/', function (req, res) {
	/* Query pending request */
	if(req.session.user_id){
		con.query("SELECT * FROM house WHERE user_id = '" +req.session.user_id+"'; SELECT * FROM reservation INNER JOIN users USING (user_id) INNER JOIN house USING(house_id)  WHERE reservation_status ='pending' AND house.user_id ='"+req.session.user_id+"'", function (err, result) {
			res.render('pages/index', {
				siteTitle	: siteTitle,
				pageTitle	: "Pending",
				items 		: result[0],
				reservations: result[1]
			});
		});
	} else {
		res.redirect('/house/login');
	}
});



	//	con.query("SELECT * FROM reservation INNER JOIN users USING (user_id) INNER JOIN house USING(house_id)  WHERE reservation_status ='pending' AND house.user_id ='"+req.session.user_id+"'", function (err, result) {
	//			res.render('partials/reservation', {
	//				siteTitle	: siteTitle,
	//				pageTitle	: "Pending",
	//				names 		: result
	//			});
	//		});

/* Page loads, load data */
app.get('/house/login', function (req, res) {
	res.render('pages/login.ejs', {
		siteTitle	: siteTitle,
		pageTitle	: "Login"
	});
});

/* Add a house*/
app.get('/house/add', function (req, res) {
	/* Query pending request */	
	if(req.session.user_id){
		res.render('pages/add-house.ejs', {
			siteTitle	: siteTitle,
			pageTitle	: "Add new house",
			items 		: ''
		});
	} else {
		res.redirect('/house/login');
	}
});

/* Post 
app.post('/house/add', function(req, res) {
	var query =		"INSERT INTO `house` (house_name, house_style, house_description) VALUES ("; 
		query +=	"'"+req.body.house_name+"',";
		query +=	" '"+req.body.house_style+"',";
		query +=	" '"+req.body.house_description+"')";

		console.log(query);
	con.query(query, function(err, result) {
		if (err) throw err;
		res.redirect(baseURL);
	});
});*/

/* Add */
app.post('/house/add', (req,res) => {
	if(req.session.user_id){
		let post = {user_id:req.session.user_id,house_name:req.body.house_name, house_style:req.body.house_style, house_capacity:req.body.house_capacity,house_description:req.body.house_description, house_address:req.body.house_address, rental_type:req.body.rental_type, current_rental_fee:req.body.current_rental_fee, current_reservation_fee:req.body.current_reservation_fee, house_status:'available'};
		let sql = 'INSERT INTO house SET ?';
		query = con.query(sql, post, function(err, result) {
			if (result.affectedRows) {
				res.redirect(baseURL);
			}
		});
	} else {
		res.redirect('/house/login');
	}
});

/* Edit */
app.get('/house/edit/:house_id', function(req,res) {
	if(req.session.user_id){
		con.query("SELECT * FROM house WHERE house_id = '"+ req.params.house_id + "'", function(err, result) {

			res.render('pages/edit-house.ejs', {
				siteTitle: siteTitle,
				pageTitle: "Edit a house: " + result[0].house_name,
				item: result
			});
		});
	} else {
		res.redirect('/house/login');
	}		
});

app.post('/house/edit/:house_id', function(req, res) {
	if(req.session.user_id){
		var query =		"UPDATE `transient`.`house` SET"; 
			query +=	" `house_name` ='"+req.body.house_name+"',";
			query +=	" `house_style` ='"+req.body.house_style+"',";
			query +=	" `house_capacity` ='"+req.body.house_capacity+"',";
			query +=	" `house_description` ='"+req.body.house_description+"',";
			query +=	" `house_address` = '"+req.body.house_address+"',";
			query +=	" `rental_type` = '"+req.body.rental_type+"',";
			query +=	" `current_rental_fee` = '"+req.body.current_rental_fee+"',";
			query +=	" `current_reservation_fee` = '"+req.body.current_reservation_fee+"',";
			query +=	" `house_status` = '"+req.body.house_status+"',";
			query +=	" `house_description` ='"+req.body.house_description+"'";
			query +=	" WHERE `house`.`house_id` = '"+req.body.house_id+"';";

			console.log(query);
		con.query(query, function(err, result) {
			if (err) throw err;
			else if (result.affectedRows) {
				res.redirect(baseURL);			
			}
		});
	} else {
		res.redirect('/house/login');
	}		
});

/* Load reservations */
app.get('/house/reservations', function (req, res) {
	if(req.session.user_id){
		con.query("SELECT * FROM reservation INNER JOIN users USING (user_id) INNER JOIN house USING(house_id)  WHERE reservation_status ='pending' AND house.user_id ='"+req.session.user_id+"'", function (err, result) {
			res.render('pages/reservations', {
				siteTitle	: siteTitle,
				pageTitle	: "Reservations",
				items 		: result
			});
		});
	} else {
		res.redirect('/house/login');
	}		
});

/* Allow reservations */
app.get('/house/reservations/accept/:house_id', function (req, res) {
	if(req.session.user_id){
		con.query("UPDATE `house` SET `house_status` = 'reserved' WHERE `house`.`house_id` = '" +req.params.house_id+"'; UPDATE `reservation` INNER JOIN house USING(house_id) SET `reservation_status` = 'accepted' WHERE `house`.`house_id`= '" +req.params.house_id+"'", function(err, result) {
			if (result[0].affectedRows) {
				//res.redirect('/house/reservations');
			}
		});
		con.query("SELECT * FROM reservation INNER JOIN house USING(house_id) WHERE house_id = '"+req.params.house_id+"' AND `house_status` = 'reserved'", function(err,result) {
			if (err) throw err;
			let post = {reservation_id:result[0].reservation_id, rental_startdate:result[0].reservation_startdate, rental_enddate:result[0].reservation_enddate, rental_fee:result[0].current_rental_fee, fee_to_provider:result[0].current_reservation_fee, rental_status:'ongoing'};
			let sql = 'INSERT INTO rental SET ?';
			query = con.query(sql, post, function(err, result) {
				if (err) throw err;
				if (result.affectedRows) {
					res.redirect('/house/reservations');
				}
			});
		});
	} else {
		res.redirect('/house/login');
	}		
});

/* Deny reservations */
app.get('/house/reservations/deny/:house_id', function (req, res) {
	if(req.session.user_id){
		con.query("UPDATE `house` SET `house_status` = 'reserved' WHERE `house`.`house_id` = '" +req.params.house_id+"'; UPDATE `reservation` INNER JOIN house USING(house_id) SET `reservation_status` = 'rejected' WHERE `house`.`house_id`= '" +req.params.house_id+"'", function(err, result) {
			if (result[0].affectedRows) {
				res.redirect('/house/reservations');
			}
		});
	} else {
		res.redirect('/house/login');
	}		
});

/* Allow reservations */
app.get('/house/reservations/acceptchange/:house_id', function (req, res) {
	if(req.session.user_id){
		con.query("UPDATE `house` SET `house_status` = 'reserved' WHERE `house`.`house_id` = '" +req.params.house_id+"'; UPDATE `reservation` INNER JOIN house USING(house_id) SET `reservation_status` = 'accepted' WHERE `house`.`house_id`= '" +req.params.house_id+"'", function(err, result) {
			if (result[0].affectedRows) {
				//res.redirect('/house/allreservations');
			}
		});
		con.query("SELECT * FROM reservation INNER JOIN house USING(house_id) WHERE house_id = '"+req.params.house_id+"' AND `house_status` = 'reserved'", function(err,result) {
			let post = {reservation_id:result[0].reservation_id, rental_startdate:result[0].reservation_startdate, rental_enddate:result[0].reservation_enddate, rental_fee:result[0].current_rental_fee, fee_to_provider:result[0].current_reservation_fee, rental_status:ongoing};
			let sql = 'INSERT INTO rental SET ?';
			query = con.query(sql, post, function(err, result) {
				if (err) throw err;
				if (result.affectedRows) {
					res.redirect('/house/allreservations');
				}
			});
		});
	} else {
		res.redirect('/house/login');
	}		
});

/* Deny reservations */
app.get('/house/reservations/denychange/:house_id', function (req, res) {
	if(req.session.user_id){
		con.query("UPDATE `house` SET `house_status` = 'reserved' WHERE `house`.`house_id` = '" +req.params.house_id+"'; UPDATE `reservation` INNER JOIN house USING(house_id) SET `reservation_status` = 'rejected' WHERE `house`.`house_id`= '" +req.params.house_id+"'", function(err, result) {
			if (result[0].affectedRows) {
				res.redirect('/house/allreservations');
			}
		});
	} else {
		res.redirect('/house/login');
	}
});

/* Load all reservations */
app.get('/house/allreservations', function (req, res) {
	if(req.session.user_id){
		con.query("SELECT * FROM reservation INNER JOIN users USING (user_id) INNER JOIN house USING(house_id)  WHERE house.user_id ='"+req.session.user_id+"'", function (err, result) {
			res.render('pages/allreservations', {
				siteTitle	: siteTitle,
				pageTitle	: "All Reservations",
				items 		: result
			});
		});
	} else {
		res.redirect('/house/login');
	}		
});

/* Load all rentals */
app.get('/house/rentals', function (req, res) {
	if(req.session.user_id){
		con.query("SELECT *, reservation_enddate < NOW() AS finished FROM reservation INNER JOIN users USING(user_id) INNER JOIN rental USING(reservation_id) INNER JOIN house USING(house_id) WHERE reservation_status = 'accepted' AND rental_status = 'ongoing' AND house.user_id = '"+req.session.user_id+"';", function (err, result) {
			for (var c = 0; c < result.length; c++) {
				if(result[c].finished == 1) {
					con.query("UPDATE `rental` SET `rental_status` = 'completed' WHERE `reservation_id` = '" +result[c].reservation_id+"'", function(err, resulta) {
							if (resulta.affectedRows) {
								console.log(resulta.affectedRows);
							}
					});
				}
			}		
		});
		con.query("SELECT * FROM reservation INNER JOIN users USING(user_id) INNER JOIN rental USING(reservation_id) INNER JOIN house USING(house_id) WHERE reservation_status = 'accepted' AND rental_status = 'ongoing' AND house.user_id = '"+req.session.user_id+"'; SELECT * FROM reservation INNER JOIN users USING(user_id) INNER JOIN rental USING(reservation_id) INNER JOIN house USING(house_id) WHERE reservation_status = 'accepted' AND rental_status = 'completed' AND house.user_id = '"+req.session.user_id+"'", function (err, result) {
			res.render('pages/rentals', {
				siteTitle	: siteTitle,
				pageTitle	: "Ongoing Rentals",
				items 		: result[0],
				finished	: result[1]
			});
		});
	} else {
		res.redirect('/house/login');
	}		
});

/* Confirm payment */
app.get('/house/confirm/:reservation_id', function(req,res) {
	if(req.session.user_id){
		con.query("SELECT *, reservation.user_id AS customer_id, reservation_enddate < NOW() FROM reservation INNER JOIN users USING(user_id) INNER JOIN rental USING(reservation_id) INNER JOIN house USING(house_id) WHERE reservation_status = 'accepted' AND rental_status = 'completed' AND house.user_id = '"+req.session.user_id+"' AND reservation_id = '"+req.params.reservation_id+"';", function(err, result) {
			res.render('pages/confirm.ejs', {
				siteTitle: siteTitle,
				pageTitle: "Confirm Payment",
				item: result
			});
		});
	} else {
		res.redirect('/house/login');
	}		
});

/* Confirm payment */
app.post('/house/confirm/:reservation_id', function (req,res) {
	if(req.session.user_id){
		console.log(req.body.user_id);
		console.log(req.body.rental_id);
		console.log(req.body.payment_date);
		console.log(req.body.payment_amount);
		console.log(req.body.payment_remarks);
		let post = {user_id:req.body.user_id, rental_id:req.body.rental_id, payment_date:req.body.payment_date, payment_amount:req.body.payment_amount, payment_remarks:req.body.payment_remarks};
		let sql = 'INSERT INTO payments SET ?';
		query = con.query(sql, post, function(err, result) {
			if (err) throw err;
			if (result.affectedRows) {
				res.redirect('/house/transactions');
			}
		});
	} else {
		res.redirect('/house/login');
	}	
});

/* Load all transactions */
app.get('/house/transactions', function (req, res) {
	if(req.session.user_id){
		con.query("SELECT * FROM payments INNER JOIN rental USING(rental_id) INNER JOIN reservation USING(reservation_id) INNER JOIN house USING (house_id) INNER JOIN users ON users.user_id = house.user_id WHERE house.user_id = '"+req.session.user_id+"';", function (err, result) {
			res.render('pages/transactions', {
				siteTitle	: siteTitle,
				pageTitle	: "All Transactions",
				items 		: result
			});
		});
	} else {
		res.redirect('/house/login');
	}		
});

/* Delete */
app.get('/house/delete/:house_id', function(req,res) {
	if(req.session.user_id){
		con.query("DELETE FROM house WHERE house_id = '" +req.params.house_id+"'", function(err, result) {
			if (result.affectedRows) {
				res.redirect(baseURL);
			}
		});
	} else {
		res.redirect('/house/login');
	}		
});


/* Establish a server */
var server = app.listen(4000,function() {
	console.log("Server started on 4000!");
});